export type NormalizedWebhookEvent =
  | { type: 'payment.succeeded'; orderId: string; amount: number; txnRef: string; raw: any }
  | { type: 'payment.failed'; orderId: string; raw: any }
  | { type: 'unknown'; raw: any };

export interface PaymentProvider {
  createCheckoutSession(order: any): Promise<any>;
  verifyWebhook(req: any): Promise<NormalizedWebhookEvent>;
}