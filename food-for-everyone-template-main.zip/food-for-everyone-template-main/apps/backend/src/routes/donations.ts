import express, { Router } from 'express';
import { z } from 'zod';
import Stripe from 'stripe';
import { prisma } from '../lib/prisma.js';
import { requireAuth, requireRole } from '../middleware/auth.js';
import { ah } from '../utils/asyncHandler.js';
import { notifyEmail, createNotification } from '../services/notifications.js';
import { getPaymentProvider } from '../services/payments/index.js';

export const router = Router();

const stripe = process.env.STRIPE_SECRET_KEY
  ? new Stripe(process.env.STRIPE_SECRET_KEY, { apiVersion: '2025-10-29.clover' })
  : null;

// ─── GET all open donation requests (public) ────────────────────────────────
router.get('/', ah(async (req, res) => {
  const { listingId } = req.query;
  const where: any = { status: 'OPEN' };
  if (listingId) where.listingId = String(listingId);

  const requests = await prisma.donationRequest.findMany({
    where,
    include: {
      center: { select: { name: true, address: true } },
      listing: { select: { id: true, title: true, category: true, images: true, discountPrice: true, expiresAt: true, qtyAvailable: true } }
    },
    orderBy: { createdAt: 'desc' }
  });
  res.json({ requests });
}));


// ─── GET my donation history (Customer) ──────────────────────────────────────
router.get('/my/history', requireAuth, ah(async (req: any, res) => {
  const donations = await prisma.donation.findMany({
    where: { customerId: req.user!.sub, status: 'SUCCEEDED' },
    include: { 
      donationRequest: { 
        include: { 
          listing: { 
            include: { provider: true }
          },
          orders: { select: { orderNumber: true }, take: 1 }
        } 
      } 
    },
    orderBy: { createdAt: 'desc' }
  });
  res.json({ donations });
}));

// ─── GET my donation requests (Donation Center) ───────────────────────────────
router.get('/center/my-requests', requireAuth, requireRole('DONATION_CENTER'), ah(async (req: any, res) => {
  const requests = await prisma.donationRequest.findMany({
    where: { centerId: req.user!.sub },
    include: {
      listing: { select: { title: true, images: true, discountPrice: true } },
      donations: { 
        where: { status: 'SUCCEEDED' }, 
        select: { amount: true, createdAt: true, customer: { select: { name: true } } } 
      },
      activities: {
        orderBy: { createdAt: 'desc' },
        take: 1
      }
    },
    orderBy: { createdAt: 'desc' }
  });
  res.json({ requests });
}));

// ─── GET single donation request ─────────────────────────────────────────────
router.get('/:id', ah(async (req, res) => {
  const request = await prisma.donationRequest.findUnique({
    where: { id: req.params.id },
    include: {
      center: { select: { name: true, address: true } },
      listing: { select: { id: true, title: true, category: true, images: true, discountPrice: true, expiresAt: true, qtyAvailable: true } },
      donations: {
        where: { status: 'SUCCEEDED' },
        orderBy: { createdAt: 'desc' },
        take: 20,
        select: { amount: true, createdAt: true, customer: { select: { name: true } } }
      }
    }
  });
  if (!request) return res.status(404).json({ error: 'Not found' });
  res.json({ request });
}));

// ─── CREATE donation request (Donation Center only) ──────────────────────────
router.post('/', requireAuth, requireRole('DONATION_CENTER'), ah(async (req: any, res) => {
  const body = z.object({
    title: z.string().min(3),
    description: z.string().optional(),
    listingId: z.string().optional(),
    targetAmount: z.coerce.number().positive(),
    targetQty: z.coerce.number().int().positive().optional(),
    closesAt: z.string().optional()
  }).parse(req.body);

  const request = await prisma.donationRequest.create({
    data: {
      centerId: req.user!.sub,
      title: body.title,
      description: body.description,
      listingId: body.listingId || null,
      targetAmount: body.targetAmount,
      targetQty: body.targetQty || 0,
      closesAt: body.closesAt ? new Date(body.closesAt) : null
    }
  });
  res.json({ request });
}));

// ─── UPDATE donation request (Donation Center / Admin) ───────────────────────
router.patch('/:id', requireAuth, requireRole('DONATION_CENTER', 'ADMIN'), ah(async (req: any, res) => {
  const { id } = req.params;
  const data = z.object({
    title: z.string().optional(),
    description: z.string().optional(),
    status: z.enum(['OPEN', 'FULFILLED', 'CLOSED']).optional()
  }).parse(req.body);

  const existing = await prisma.donationRequest.findUnique({ where: { id } });
  if (!existing) return res.status(404).json({ error: 'Not found' });
  if (req.user!.role !== 'ADMIN' && existing.centerId !== req.user!.sub) return res.status(403).json({ error: 'Forbidden' });

  const updated = await prisma.donationRequest.update({ where: { id }, data });
  res.json({ request: updated });
}));

// ─── INITIATE donation via Configured Payment Provider (Customer) ───────────
router.post('/:id/checkout', requireAuth, ah(async (req: any, res) => {
  console.log('--- DONATION CHECKOUT START ---');
  try {
    const { amount } = z.object({ amount: z.coerce.number().positive().min(10) }).parse(req.body);
    console.log('Amount:', amount);

    const request = await prisma.donationRequest.findUnique({
      where: { id: req.params.id },
      include: { listing: true }
    });
    console.log('Request found:', !!request);
    
    if (!request) return res.status(404).json({ error: 'Donation request not found' });
    if (request.status !== 'OPEN') return res.status(400).json({ error: 'Donation request is no longer open' });

    // Check if amount exceeds remaining needed
    const remainingNeeded = Number(request.targetAmount) - Number(request.raisedAmount);
    if (amount > remainingNeeded + 0.01) { // 0.01 buffer for float issues
      return res.status(400).json({ error: `You can only donate up to LKR ${remainingNeeded.toFixed(2)} for this request.` });
    }

    console.log('Finding buyer:', req.user!.sub);
    const buyer = await prisma.user.findUnique({ where: { id: req.user!.sub } });
    
    // Create pending Donation record
    const donation = await prisma.donation.create({
      data: {
        customerId: req.user!.sub,
        donationRequestId: request.id,
        amount,
        status: 'INITIATED'
      }
    });

    const provider = getPaymentProvider();
    
    // Prepare a pseudo-order for the provider
    const pseudoOrder = {
      id: donation.id,
      total: amount,
      items: [{ title: `Donation: ${request.title}` }],
      buyer: {
        name: buyer?.name || 'Customer',
        email: buyer?.email || 'noreply@example.com'
      }
    };

    const session = await provider.createCheckoutSession(pseudoOrder);
    
    if (session.url && !session.fields) {
      await prisma.donation.update({ where: { id: donation.id }, data: { stripeSessionId: session.url } });
    }

    res.json(session);
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Internal Server Error' });
  }
}));

// Close and claim partial donations
router.post('/:id/claim', requireAuth, ah(async (req, res) => {
  const { id } = req.params;
  const userId = req.user!.sub;

  const request = await prisma.donationRequest.findFirst({
    where: { id, centerId: userId, status: 'OPEN' },
    include: { listing: true }
  });

  if (!request) return res.status(404).json({ error: 'Active donation request not found' });
  if (Number(request.raisedAmount) <= 0) return res.status(400).json({ error: 'No donations have been made to this request yet' });

  const price = Number(request.listing?.discountPrice || 0);
  if (price <= 0) return res.status(400).json({ error: 'Invalid listing price' });

  const qtyToClaim = Math.floor(Number(request.raisedAmount) / price);
  if (qtyToClaim <= 0) return res.status(400).json({ error: 'Funds are insufficient to claim even one unit' });

  await prisma.$transaction(async (tx) => {
    // 1. Create Order for the center (Marked as PAID)
    await tx.order.create({
      data: {
        buyerId: userId,
        providerId: request.listing!.providerId,
        type: 'DONATION',
        fulfillmentMode: 'PICKUP',
        paymentMethod: 'ONLINE',
        status: 'PAID',
        donationCenterId: userId,
        donationRequestId: request.id,
        subtotal: price * qtyToClaim,
        total: price * qtyToClaim,
        items: {
          create: {
            listingId: request.listing!.id,
            providerId: request.listing!.providerId,
            qty: qtyToClaim,
            unitPrice: price,
            snapshotExpiresAt: request.listing!.expiresAt
          }
        }
      }
    });

    // 2. Mark request as FULFILLED
    await tx.donationRequest.update({
      where: { id },
      data: { status: 'FULFILLED', fulfilledQty: qtyToClaim }
    });

    // Note: Stock was already decremented incrementally during individual donation payments.
    console.log(`Donation request ${id} manually claimed by center.`);
  });

  res.json({ success: true, message: `Successfully claimed ${qtyToClaim} units.` });
}));

// ─── Stripe webhook for donation payments ─────────────────────────────────────
router.post('/webhook/stripe', express.raw({ type: 'application/json' }), ah(async (req, res) => {
  if (!stripe) return res.status(500).json({ error: 'Stripe not configured' });

  const sig = req.headers['stripe-signature'];
  const webhookSecret = process.env.STRIPE_DONATION_WEBHOOK_SECRET || process.env.STRIPE_WEBHOOK_SECRET;

  if (!sig || !webhookSecret) return res.status(400).json({ error: 'Missing signature' });

  let event: Stripe.Event;
  try {
    event = stripe.webhooks.constructEvent(req.body, sig, webhookSecret);
  } catch (err: any) {
    return res.status(400).json({ error: `Webhook error: ${err.message}` });
  }

  if (event.type === 'checkout.session.completed') {
    const session = event.data.object as Stripe.Checkout.Session;
    const donationId = session.metadata?.donationId || session.client_reference_id;
    
    // DEBUG: Log webhook receipt to DB
    if (donationId) {
      const tempDonation = await prisma.donation.findUnique({ where: { id: donationId } });
      if (tempDonation) {
        await prisma.notification.create({
          data: {
            userId: tempDonation.customerId,
            type: 'DEBUG',
            channel: 'IN_APP',
            payload: { message: `🔔 Stripe Webhook Received for Donation ${donationId}` }
          }
        }).catch(() => {});
      }
    }

    if (!donationId) return res.json({ received: true });
    
    const transactionResult = await prisma.$transaction(async (tx) => {
      let isFulfilled = false;
      const donation = await tx.donation.update({
        where: { id: donationId },
        data: { status: 'SUCCEEDED', stripePaymentId: session.payment_intent as string }
      });

      const updatedRequest = await tx.donationRequest.update({
        where: { id: donation.donationRequestId },
        data: {
          raisedAmount: { increment: donation.amount },
          donorCount: { increment: 1 }
        }
      });

      // 1. ALWAYS create a "Donation Received" notification for the Center
      await tx.notification.create({
        data: {
          userId: updatedRequest.centerId,
          type: 'DONATION_RECEIVED',
          channel: 'IN_APP',
          payload: {
            message: `❤️ New donation (D-${(donation as any).donationNumber?.toString().padStart(4, '0')}) of LKR ${donation.amount} received for "${updatedRequest.title}" (DR-${(updatedRequest as any).requestNumber?.toString().padStart(4, '0')})!`,
            action: 'VIEW_DONATION_DETAIL',
            requestId: updatedRequest.id
          }
        }
      });

      // 2. Check for fulfillment (more permissive check)
      const raised = Number(updatedRequest.raisedAmount);
      const target = Number(updatedRequest.targetAmount);

      if (raised >= (target - 1) && updatedRequest.status === 'OPEN') {
        await tx.donationRequest.update({ where: { id: updatedRequest.id }, data: { status: 'FULFILLED' } });
        isFulfilled = true;

        // Auto-create an order for the Donation Center if a listing was linked
        if (updatedRequest.listingId) {
          const listing = await tx.listing.findUnique({ where: { id: updatedRequest.listingId } });
          if (listing && listing.qtyAvailable > 0) {
            const price = Number(listing.discountPrice);
            const qty = Math.max(1, Math.min(listing.qtyAvailable, Math.floor(raised / price)));
            
            const o = await tx.order.create({
              data: {
                buyerId: updatedRequest.centerId,
                providerId: listing.providerId,
                type: 'DONATION',
                fulfillmentMode: 'PICKUP',
                paymentMethod: 'ONLINE',
                status: 'PAID',
                donationCenterId: updatedRequest.centerId,
                donationRequestId: updatedRequest.id,
                subtotal: price * qty,
                total: price * qty,
              }
            });
            await tx.orderItem.create({
              data: { 
                orderId: o.id, 
                listingId: listing.id, 
                providerId: listing.providerId,
                qty, 
                unitPrice: price, 
                snapshotExpiresAt: listing.expiresAt
              }
            });
            await tx.listing.update({
              where: { id: listing.id },
              data: { qtyAvailable: { decrement: qty } }
            });
          }
        }

        // Full Funding Notification
        await tx.notification.create({
          data: {
            userId: updatedRequest.centerId,
            type: 'DONATION_FULFILLED',
            channel: 'IN_APP',
            payload: {
              message: `🎉 Your donation request "DR-${(updatedRequest as any).requestNumber?.toString().padStart(4, '0')}" (${updatedRequest.title}) is fully funded!`,
              action: 'VIEW_DONATION_DETAIL',
              requestId: updatedRequest.id
            }
          }
        });

        if (updatedRequest.listingId) {
          const listing = await tx.listing.findUnique({ 
            where: { id: updatedRequest.listingId },
            include: { provider: true }
          });
          if (listing?.provider?.userId) {
            await tx.notification.create({
              data: {
                userId: listing.provider.userId,
                type: 'DONATION_ORDER_READY',
                channel: 'IN_APP',
                payload: {
                  message: `🎁 Donation order for "${listing.title}" (DR-${(updatedRequest as any).requestNumber?.toString().padStart(4, '0')}) has been fully funded!`,
                  action: 'VIEW_ORDER_DETAIL',
                  requestId: updatedRequest.id
                }
              }
            });
          }
        }
      }

      return { requestId: updatedRequest.id, isFulfilled, amount: donation.amount };
    });

    if (!transactionResult) return res.json({ received: true });

    // 3. Handle External Side-Effects AFTER Transaction Success
    const dr = await prisma.donationRequest.findUnique({
      where: { id: transactionResult.requestId },
      include: {
        center: { include: { user: true } },
        listing: { include: { provider: true } },
        donations: { where: { status: 'SUCCEEDED' }, include: { customer: true } }
      }
    });

    if (dr) {
      const io = req.app.get('io') || (global as any).__io;
      if (io) {
        // Real-time progress update for the progress bar
        io.emit('donation:progress', {
          requestId: dr.id,
          raisedAmount: Number(dr.raisedAmount),
          donorCount: dr.donorCount
        });

        // Alert Center about the NEW donation
        const receiveMsg = `❤️ New donation of LKR ${transactionResult.amount} received!`;
        io.to(`user:${dr.centerId}`).emit('notification', { 
          type: 'DONATION_RECEIVED', 
          message: receiveMsg,
          requestId: dr.id
        });

        // If fully funded, send alerts
        if (transactionResult.isFulfilled) {
          // Notify Center
          const centerMsg = `🎉 Your donation request "${dr.title}" is fully funded!`;
          await notifyEmail(dr.center.user.email, `🎉 Funded: ${dr.title}`, `<p>${centerMsg}</p>`).catch(() => {});
          io.to(`user:${dr.centerId}`).emit('notification', { 
            type: 'DONATION_FULFILLED', 
            message: centerMsg,
            requestId: dr.id
          });

          // Notify Provider
          if (dr.listing?.provider?.userId) {
            const providerMsg = `🎁 Donation order for "${dr.listing.title}" is ready!`;
            io.to(`user:${dr.listing.provider.userId}`).emit('notification', { 
              type: 'DONATION_ORDER_READY', 
              message: providerMsg,
              requestId: dr.id
            });
          }

          // Notify Donors
          for (const d of dr.donations) {
            await notifyEmail(d.customer.email, '❤️ Thank you!', `<p>The request "${dr.title}" is funded!</p>`).catch(() => {});
          }
          
          io.emit('donation:fulfilled', { requestId: dr.id });
        }
      }
    }
  }

  res.json({ received: true });
}));


