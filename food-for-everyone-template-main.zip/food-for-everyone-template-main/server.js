// Hostinger Node.js Web App Entry File
import('./apps/backend/dist/index.js');
